"use strict";
exports.id = 4626;
exports.ids = [4626];
exports.modules = {

/***/ 4626:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);




function TermOfUseComponent() {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
      children: "Logistics Terms and Conditions"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "GOFAZ ROSSUL LOGISTICS TERMS AND  CONDITIONS OF CONTRACT"
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "By acceptance of services of Gofaz Rossul Logistics or Agents, Customer and any other  party with an interest in the goods agree to these Terms and Conditions of  Contract."
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "Gofaz Rossul Logistics Terms\xA0and Conditions\xA0are Subject\xA0to  Change\xA0at Gofaz Rossul Logistics\u2019 Sole Discretion Without Notice\xA0to Any Parties \u2013 Rev.  2/10"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "I. Definitions:"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "Gofaz Rossul Logistics:"
      }), " Gofaz Rossul Logistics, is hereinafter  referred to as Gofaz Rossul Logistics. Gofaz Rossul Logistics as referenced hereinafter shall include, but is not  limited to the following services: electrical (a/k/a TSE/Trade Show  Electrical), rigging, material handling, installation and dismantle, and  logistics provided by Gofaz Rossul Logistics personnel to exhibitor pursuant to any purchase of  Services. ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "Agents:"
      }), " Gofaz Rossul Logistics\u2019 agents, sub-contractors, carriers, and  the agents of each; ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "Customer:"
      }), " Exhibitor or other party  requesting Services from Gofaz Rossul Logistics; ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "Goods:"
      }), " Exhibits, property, and  commodities of any type for which Gofaz Rossul Logistics is requested to perform Services; ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "Carrier:"
      }), " Motor carrier, van line, air carrier, or air or surface freight forwarder; ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "Shipper:"
      }), " Party who tenders Goods to Carrier for transportation; ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "Cold Storage:"
      }), " Holding of Goods in a climate controlled area; ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "Consignee:"
      }), " Party to whom goods are shipped; ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "ICCTA:"
      }), " Part B 49 U.S.C.  Sections 13101 \u2013 14914, of the ICC Termination Act of 1995; ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "HAZMAT:"
      }), " Those articles, commodities and/or goods defined as hazardous in 49 CFR Parts  s171-177. ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "Services:"
      }), " Warehousing, transportation, drayage,  and/or related services.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "II. Scope:"]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "These Terms and Conditions shall be binding upon Customer, Gofaz Rossul Logistics, and their  respective Agents, representatives, Shipper and Consignee, including but not  limited to Customer contracted labor such as Customer Appointed Contractors and  Installation and Dismantle Companies, and any other party with an interest in  the Goods. Each shall have the benefit of and be bound by all provisions stated  herein, including but not limited to time limits and limitations of liability.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "III. Customer Obligations:"]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "a. ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Payment for Services."
      }), " Customer, Shipper, and Consignee shall be jointly liable for all unpaid charGofaz Rossul Logistics  for services performed by Gofaz Rossul Logistics or Agents. Customer authorizes Gofaz Rossul Logistics to charge its  credit card directly for services rendered on Customer\u2019s behalf after departure  by placing an order on-line, via fax, phone or through a work order on site.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "b. ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Credit Terms."
      }), " All  charGofaz Rossul Logistics are due before Services are performed unless other arrangements have  been made in advance. Gofaz Rossul Logistics has the right to require prepayment or guarantee of  the charGofaz Rossul Logistics at the time of request for Services. A failure to pay timely will  result in Customer having to pay in cash in advance for future services. Gofaz Rossul Logistics  retains its right to hold Customers\u2019 Goods for non-payment. If a credit card is  provided to Gofaz Rossul Logistics, Gofaz Rossul Logistics is authorized to bill to such credit card any unpaid  charGofaz Rossul Logistics for services provided to Customer, including charGofaz Rossul Logistics for return  shipping. Any charGofaz Rossul Logistics not paid within 30 days of delivery will be subject to  interest at 1 1/2% per month until paid.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "c. ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Proper Description."
      }), " Customer is obligated to disclose to Gofaz Rossul Logistics and Carrier if Customer\u2019s packaGofaz Rossul Logistics  contain items that are considered Hazardous Materials or Dangerous Goods.  Customer has the obligation to ensure that each package is properly and  completely described, is properly marked and addressed, and is packaged  adequately to protect the contents during transportation. Customer must provide  all documentation for HAZMAT shipping as required by the Department of  Transportation. Customer hereby agrees to provide Gofaz Rossul Logistics and Carrier with accurate  information in order to allow for all proper disclosures to be made on Customer\u2019s  shipment. Customer is responsible for all placarding.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "IV. Mutual Obligations:"]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "A."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "ICCTA Waiver."
      }), " Customer and Gofaz Rossul Logistics expressly and mutually waive, to the extent permissible under  law, any and all rights and remedies each may have under ICCTA to the extent  those provisions conflict with these Terms and Conditions.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "B."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Customer to Gofaz Rossul Logistics."
      }), " Customer shall defend, hold harmless and indemnify Gofaz Rossul Logistics from and against any  claims, lawsuits, demands, liability, costs and expenses, including reasonable  attorney\u2019s fees and court costs, resulting from any injury to or death of  persons, or damage to property other than Goods, relating to or arising from  performance of Services herein. Customer agrees to indemnify and hold Gofaz Rossul Logistics  harmless for any and all acts of its representatives and agents, including but  not limited to Customer Appointed Contractors and Installation and Dismantle  Companies, any subtenant or other user of its space or any agents or employees  engaged in business on behalf of Customer or present at Customer\u2019s invitation,  including supervision of labor secured through Gofaz Rossul Logistics. Customer\u2019s obligations  under this provision shall not apply to Gofaz Rossul Logistics\u2019 own negligence and/or willful  misconduct. Unless otherwise agreed, Customer agrees to indemnify and Gofaz Rossul Logistics  harmless for any transportation charGofaz Rossul Logistics. ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "CUSTOMER ACKNOWLED Gofaz Rossul Logistics THAT THE  SHOW SITE IS AN ACTIVE WORK ZONE AND CUSTOMER, ITS AGENTS, EMPLOYEES AND  REPRESENTATIVES ARE PRESENT AT THEIR OWN RISK."
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "C."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Gofaz Rossul Logistics to Customer."
      }), " To  the extent of Gofaz Rossul Logistics\u2019 own negligence and/or willful misconduct, and subject to the  limitations of liability below, Gofaz Rossul Logistics shall defend, hold harmless and indemnify  Customer from and against any claims, lawsuits, demands, liability, costs and  expenses, including reasonable attorney\u2019s fees and court costs, resulting from  any injury to or death of persons, or damage to property other than Goods. Gofaz Rossul Logistics\u2019  obligations under this provision shall not apply to claims for bodily injury  arising a) from Customer\u2019s presence in areas which have been marked as \u201Coff  limits to exhibitors\u201D; and b) when exhibitors are present in the facility prior  or subsequent to the effective dates or hours of exhibitor\u2019s space lease with  show management.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "V. DISCLAIMER AND LIMITATION  OF LIABILITY"]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "UNDER NO CIRCUMSTANCES WILL ANY PARTY BE LIABLE FOR SPECIAL, INCIDENTAL,  CONSEQUENTIAL, INDIRECT OR PUNITIVE DAMAGofaz Rossul Logistics, INCLUDING BUT NOT LIMITED TO LOSS  OF PROFITS OR INCOME. Gofaz Rossul Logistics SHALL BE LIABLE, SUBJECT TO THE LIMITATIONS CONTAINED  HEREIN, FOR LOSS OR DAMAGE TO GOODS ONLY IF SUCH LOSS OR DAMAGE IS CAUSED BY  THE DIRECT NEGLIGENCE OR WILLFUL MISCONDUCT OF Gofaz Rossul Logistics. CLAIMS PRESENTED FOR LOSS  OR DAMAGE ARISING OUT OF INCIDENTS REFERENCED IN SECTION VI HEREIN WILL BE  DENIED. "
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "VI. No Liability for Loss or  Damage to Goods"]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "A."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Condition of Goods"
      }), ":  Gofaz Rossul Logistics shall not be liable for damage, loss, or delay to uncrated freight, freight  improperly packed, glass breakage or concealed damage. Gofaz Rossul Logistics shall not be liable  for ordinary wear and tear in handling of Goods or for damage to shrink wrapped  Goods. All Goods shall be able to withstand handling by heavy equipment,  including but not limited to forklifts, cranes, or dollies. It is the  Customer\u2019s responsibility to ensure that Goods are packaged correctly prior to  shipment or movement on or off the Show floor.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "B."]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Receipt of Goods"
      }), ":  Gofaz Rossul Logistics shall not be liable for Goods received without receipts, freight bills, or  specified piece count on receipts or freight bills, or for bulk shipments  (i.e., UPS, air freight, or van lines). Such Goods shall be delivered to booth  without the guarantee of piece count or condition.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "C."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Force Majeure"
      }), ": Gofaz Rossul Logistics  shall not be liable for loss or damage that results from Acts of God, weather  conditions, act or default of Customer, shipper, or the owner of the Goods,  inherent nature of the Goods, public enemy, public authority, labor disputes,  and acts of terrorism or war.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "D."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Cold Storage"
      }), ": Goods  requiring cold storage are stored at Customer\u2019s own risk. Gofaz Rossul Logistics assumes no  liability or responsibility for Cold Storage.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "E."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Unattended Goods"
      }), ": Gofaz Rossul Logistics  assumes no liability for loss or damage to unattended Goods received at Show  Site at any time from the point of receipt of inbound Goods until the loading  of the outbound Goods, including the entire term of the respective show or  exhibition. Customer is responsible for insuring its own Goods for any and all  risk of loss.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "F."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Empty Storage"
      }), ": Gofaz Rossul Logistics  assumes no liability for loss or damage to Goods or crates, or the contents  therein, while containers are in Empty Storage. It is Customer\u2019s sole  responsibility to affix the appropriate labels available at the Gofaz Rossul Logistics Service  Desk for empty container storage, and ensures that any pre-existing empty  labels are removed.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "G."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Forced Freight"
      }), ": Gofaz Rossul Logistics  is not liable for Customer Goods left on the show floor after the show closing  deadline, with or without a Material Handling Services/Straight Bill of Lading  signed by Customer. It is Customer\u2019s responsibility to complete accurate  paperwork for shipping and to ensure Customer Goods are properly labeled. If  Customer Goods remain on the floor after the show closing deadline, Gofaz Rossul Logistics has the  right to remove the Customer Goods. Gofaz Rossul Logistics is authorized by Customer to proceed in  the manner chosen by Customer on the Order of Material Handling  Services/Straight Bill of Lading, if one has been completed, or otherwise, to  ship Customer Goods at the discretion of Gofaz Rossul Logistics and at Customer\u2019s expense. Gofaz Rossul Logistics  shall incur no liability for such shipment. Gofaz Rossul Logistics retains the right to dispose of  Customer Goods without liability if left on the show floor unattended, without  labels or not correctly labeled.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "H."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Concealed Damage"
      }), ":  Gofaz Rossul Logistics shall not be liable for concealed loss or damage including but not limited  to; glass, electronic equipment, prototypes, original art, uncrated Goods, or  improperly packaged or labeled Goods. ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "  I."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Unattended Booth"
      }), ":  Gofaz Rossul Logistics shall not be liable for any loss or damage occurring while the Goods are  unattended in Customer\u2019s booth at any time, including, but not limited to, the  time the Goods are delivered to the dock until the time the Goods are received  by Customer\u2019s chosen carrier. All Material Handling Forms and/or Straight Bills  of Lading covering outgoing Goods submitted to Gofaz Rossul Logistics will be checked at the time  of pickup from the booth and corrections to the count or condition will be  documented where discrepancies exist.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "VII. Measure of Damage"]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "A."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Sole Relief"
      }), ": If  found liable for any loss, Gofaz Rossul Logistics\u2019 sole and exclusive maximum liability for loss  or damage to Customer\u2019s Goods is limited to $.50 (USD) per pound with a maximum  liability of $100.00 (USD) per container, or $1,500.00 (USD) per shipment  whichever is less.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "B."]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Labor"
      }), ": Gofaz Rossul Logistics assumes  no liability for loss, damage, or bodily injury arising out of Customer\u2019s  supervision of Gofaz Rossul Logistics provided union labor. If Gofaz Rossul Logistics supervises labor for a fee, Gofaz Rossul Logistics  shall be liable only for actions or claims arising out of its negligent  supervision. Such liability shall be limited to the cost to Customer of the  supervised labor or the depreciated value of the Goods, whichever is less. If  Customer elects to use unsupervised labor, then Customer assumes all liability  for the actions or claims that arise out of such work, including but not  limited to loss, damage or bodily injury and shall provide Gofaz Rossul Logistics and show  management with an indemnity, including defense costs, for any claims that  result from Customers\u2019 supervision or failure to supervise assigned labor.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "VIII. Miscellaneous"]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "A."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Insurance"
      }), ": ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: ["Gofaz Rossul Logistics  IS ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
          children: "NOT"
        }), " AN INSURANCE COMPANY AND DOES NOT OFFER OR PROVIDE INSURANCE"]
      }), ".  It is the obligation of Customer to ensure Goods are insured at all times. Loss  or theft of the Goods in storage or in transit to and from the show and or  while on the show floor is the sole responsibility of Customer. Gofaz Rossul Logistics recommends  Customer arrange for all Risk Coverage.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "B."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Notice of Loss or  Damage"
      }), ": In order to have a valid claim, notice of loss or damage to Goods  must be given to Gofaz Rossul Logistics or its agent within 24 hours of occurrence (as evidenced  in an Incident Report completed at Show Site by Gofaz Rossul Logistics) or delivery of outbound  Goods.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "C."]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Filing of Claim"
      }), ":  Any claim for loss or damage to Goods must be in writing, containing facts  sufficient to identify the Goods, asserting liability for alleged loss or  damage, and making claim for the payment of a specified or determinable amount  of money. Such claim must be filed with the appropriate party within the time  limits specified herein. Damage reports, incident reports, inspection reports,  notations of shortage or damage on freight bills or other documents, do not  constitute filing of a claim.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "Claims for Goods alleged to be lost, stolen or damaged at the Show Site must be  received in writing by Gofaz Rossul Logistics within ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "thirty (30)"
      }), " days after the  close of the show.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "Claims for Goods alleged to be lost or damaged ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "during transit"
      }), " must be received by the responsible party within nine (9) months of date of  delivery of Goods. GOFAZ ROSSUL LOGISTICS subcontracts the movement of Goods to third  party carriers. Claims for damage in transit should be made directly with your  carrier as shown on the Material Handling form/ Bill of Lading.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "In the event of a dispute with Gofaz Rossul Logistics, Customer will not withhold payment or any  amount due Gofaz Rossul Logistics for Services as an offset against the amount of the alleged loss  or damage. Customer agrees to pay Gofaz Rossul Logistics prior to the close of the show for all  such charGofaz Rossul Logistics and further agrees that any claim Customer may have against Gofaz Rossul Logistics  shall be pursued independently by Customer as a separate action to be resolved  on its own merits. Gofaz Rossul Logistics retains the right to pursue collection on amounts owed  after show close, without regard to any amount alleged to be owed for damage,  or loss.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "D."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Filing of Suit"
      }), ": Any  action at law regarding loss or damage to Goods must be filed within two (2)  years of the date of declination of any part of a claim.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "E."
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("u", {
        children: "Excess Declared Value"
      }), ":  Customer may obtain a higher limitation of liability, up to $20,000 per  shipment as follows: ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "1. To request Excess Declared Value,"
      }), " (a)  Customer must state the Excess Declared Value amount in the space provided on  the Gofaz Rossul Logistics services order forms, and on the Material Handling Order Form; and; (b)  Check the box requesting Excess Declared Value, and; (c) Pay the appropriate  charge for Excess Declared Value prior to shipment date. ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "2. Cost \u2013  Excess Declared Value"
      }), " is available from Gofaz Rossul Logistics for $2.00 per $100.00 of  Excess Declared Value with a $100.00 minimum charge. ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "3. Not Insurance \u2013  Excess Declared Value is NOT INSURANCE. Gofaz Rossul Logistics IS NOT AN INSURANCE COMPANY AND  DOES NOT OFFER OR PROVIDE INSURANCE."
      }), " Gofaz Rossul Logistics will not be liable or  responsible for loss or damage to Customer Goods, unless such loss or damage is  caused by Gofaz Rossul Logistics\u2019 negligence.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
        children: "Excess Declared Value is not available for: plasma screens, LCD  screens, electronic equipment, original art, one of a kind items and/or  prototypes. Declared Value may never be purchased in excess of $20,000 for  purposes of this provision."
      }), " Gofaz Rossul Logistics\u2019 liability in all circumstances shall  be limited to the amount of this cap. Notwithstanding the foregoing, all  shipments containing the following items of extraordinary value are limited to  the maximum declared value of $500.00 (USD). 1. Clocks, jewelry, including  costume jewelry, furs or items trimmed in fur; 2. Coins, money, currency, gift  certificates, gift cards, debit cards or credit cards; 3. Personal effects  including without limitation, clothing, paper and documents or any other items  of extraordinary value. In addition, any Declared Value in excess of the  maximum stated above is null and void and the acceptance by Gofaz Rossul Logistics for carriage of  any shipment with a declared value in excess of the allowed maximums does not  constitute a waiver of these maximums. Under no circumstance will Gofaz Rossul Logistics be  responsible for any incidental, consequential or punitive damaGofaz Rossul Logistics due to loss,  damage, theft or delay of Goods or any other causes. ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "IX. Jurisdiction, Choice of  Forum"]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "This Agreement shall be governed by and construed in accordance with the  applicable laws of the United States or, alternatively, and depending on  jurisdiction, the laws of the State of Oregon. The parties hereby submit to  jurisdiction and venue in the United States Federal District Court of Oregon,  or as applicable depending upon jurisdiction, the Multnomah County Circuit  Court in Portland, Oregon.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "X. Advanced  Warehousing/Temporary Storage/Long Term Storage"]
      }), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "All terms and conditions relative to Advanced Warehousing/Temporary  Storage/Long Term Storage are contained in separate agreements titled \u201CStorage  Agreement\u201D. In the event that a Storage Agreement is not executed between the  parties, the following shall apply with respect to Gofaz Rossul Logistics\u2019 liability for  Customer\u2019s Goods. The responsibility of Gofaz Rossul Logistics with respect to Customer\u2019s Goods is  limited to the exercise of ordinary care and diligence in handling and storing  of Customer\u2019s Goods. Gofaz Rossul Logistics shall be liable only for loss or damage to Goods  caused by Gofaz Rossul Logistics\u2019 sole negligence. Gofaz Rossul Logistics\u2019 liability is limited to $.60 (USD) per  pound with a maximum liability of $100.00 (USD) per container, or $1,500.00  (USD) per shipment whichever is less. In case of partial loss or damage, the  maximum liability shall be prorated based on weight. Gofaz Rossul Logistics is not responsible for  any loss or damage to Goods caused by, but not limited to fire, theft, the  elements, vandalism, moisture, vermin, mechanical breakdown or failure,  freezing or chanGofaz Rossul Logistics in temperature, as well as any other causes beyond Gofaz Rossul Logistics\u2019  immediate control. Gofaz Rossul Logistics is not responsible for the marring, scratching or  breakage of glass or other fragile items. Gofaz Rossul Logistics is not liable for the mechanical  functions of instruments or appliances even if such articles are packed or  unpacked by Gofaz Rossul Logistics. In no event shall Gofaz Rossul Logistics be liable for special, incidental,  indirect or consequential damaGofaz Rossul Logistics, including business loss of any kind, resulting  from any damage to or loss of the Goods or from any act or failure to act.  Customer pays storage fees or costs for advance warehousing for use of the  space only. There is no guarantee of security or representations made by Gofaz Rossul Logistics as  to appropriateness of the conditions for Customer\u2019s Goods. The risk of loss  remains Customer\u2019s alone and Gofaz Rossul Logistics recommends the Customer carry and maintain  insurance in amounts sufficient to cover its risk.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}), "These terms apply to your  order."]
      }), " "]
    })]
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TermOfUseComponent);

/***/ })

};
;