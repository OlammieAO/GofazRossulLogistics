"use strict";
(() => {
var exports = {};
exports.id = 3748;
exports.ids = [3748];
exports.modules = {

/***/ 8656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _nextauth_)
});

// EXTERNAL MODULE: external "next-auth"
var external_next_auth_ = __webpack_require__(1179);
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_);
;// CONCATENATED MODULE: external "next-auth/providers"
const providers_namespaceObject = require("next-auth/providers");
var providers_default = /*#__PURE__*/__webpack_require__.n(providers_namespaceObject);
// EXTERNAL MODULE: external "mongodb"
var external_mongodb_ = __webpack_require__(7548);
// EXTERNAL MODULE: external "bcryptjs"
var external_bcryptjs_ = __webpack_require__(2773);
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].js




const options = {
  //specify providers
  providers: [providers_default().Twitter({
    clientId: "",
    clientSecret: ""
  }), providers_default().Facebook({
    clientId: "",
    clientSecret: ""
  }), providers_default().Instagram({
    clientId: "",
    clientSecret: ""
  }), providers_default().Google({
    clientId: "",
    clientSecret: ""
  }), providers_default().Credentials({
    async authorize(credentials) {
      //Connect to MongoDB DB

      /*const client = await MongoClient.connect(
          `mongodb+srv://${process.env.MONGO_USER}:${process.env.MONGO_PASS}@${process.env.MONGO_CLUSTER}.n4tnm.mongodb.net/${process.env.MONGO_DB}?retryWrites=true&w=majority`,
          { useNewUrlParser: true, useUnifiedTopology: true }
      );*/
      const client = await external_mongodb_.MongoClient.connect(`${process.env.DB_URL}://${process.env.DB_User}:${process.env.DB_Pssword}/${process.env.MONGO_DB}`); //Get all the users

      const users = await client.db().collection('customers'); //Find user with the email  

      const result = await users.findOne({
        email: credentials.email
      }); //Not found - send error res

      if (!result) {
        client.close();
        throw new Error('No user found with the email');
      } //Check hashed password with DB password


      const checkPassword = await (0,external_bcryptjs_.compare)(credentials.passowrd, result.passowrd); //Incorrect password - send response

      if (!checkPassword) {
        client.close();
        throw new Error('Password doesnt match');
      } //Else send success response


      client.close();
      return {
        email: result.email
      };
    }

  })],
  pages: {
    signIn: "/login"
  },
  database: {
    type: "sqlite",
    database: ":memory:",
    synchronize: true
  }
};
/* harmony default export */ const _nextauth_ = ((req, res) => external_next_auth_default()(req, res, options));

/***/ }),

/***/ 2773:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 7548:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 1179:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8656));
module.exports = __webpack_exports__;

})();