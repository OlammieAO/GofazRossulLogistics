"use strict";
(() => {
var exports = {};
exports.id = 5753;
exports.ids = [5753];
exports.modules = {

/***/ 4950:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7548);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2773);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_1__);



async function handler(req, res) {
  //Only POST mothod is accepted
  if (req.method === 'GET') {
    //Getting email and password from body
    const {
      track
    } = req.body; //Validate

    if (!track) {
      res.status(422).json({
        message: 'Invalid Data'
      });
      return;
    } //Connect with database

    /*
    const client = await MongoClient.connect(
        `mongodb+srv://${process.env.MONGO_USER}:${process.env.MONGO_PASS}@${process.env.MONGO_CLUSTER}.n4tnm.mongodb.net/${process.env.MONGO_DB}?retryWrites=true&w=majority`,
        { useNewUrlParser: true, useUnifiedTopology: true }
    );
    */
    //const client = await MongoClient.connect(


    const client = await mongodb__WEBPACK_IMPORTED_MODULE_0__.MongoClient.connect(`${process.env.DB_URL}://${process.env.DB_User}:${process.env.DB_Pssword}/${process.env.MONGO_DB}`);
    const db = client.db(); //Check existing

    const checkExisting = await db.collection('customers').findOne({
      tracking_id: track
    }); //Send error response if duplicate user is found

    if (checkExisting) {
      res.status(422).json({
        message: 'Track history found'
      });
      client.close();
      return;
    } //Hash password
    // const status = await db.collection('customers.itemtracking').insertOne({
    //     email,
    //     password: await hash(password, 12),
    // });
    // //Send success response
    // res.status(201).json({ message: 'User created', ...status });
    //Close DB connection


    client.close();
  } else {
    //Response for other than POST method
    res.status(500).json({
      message: 'Route not valid'
    });
  }
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

/***/ }),

/***/ 2773:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 7548:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4950));
module.exports = __webpack_exports__;

})();