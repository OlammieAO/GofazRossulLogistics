module.exports = {
  reactStrictMode: true,
  basePath: '/apps/gofazrossul',
}
